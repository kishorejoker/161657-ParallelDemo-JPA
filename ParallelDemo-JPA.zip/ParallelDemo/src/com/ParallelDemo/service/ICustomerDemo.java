package com.ParallelDemo.service;

import java.util.List;

import com.ParallelDemo.bean.CustomerDemo;
import com.ParallelDemo.bean.Passbook;

public interface ICustomerDemo {
	public boolean customerDetails(CustomerDemo cd);
	public String deposit(String mobno,double amt);
	public String withdraw(String mobno,double amt);
	public CustomerDemo showBalance(String mobno);
	public void fundTransfer(String rmobno, String smobno, double amt);
	public List<Passbook> printTransactions(String mobno);
	public CustomerDemo displayDetails(String mobno);

}
